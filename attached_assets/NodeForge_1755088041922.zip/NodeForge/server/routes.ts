import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage.js";
import { crawlerService } from "./crawler.js";
import { crawlConfigSchema } from "@shared/schema";
import { z } from "zod";
import fs from 'fs/promises';

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all crawl jobs
  app.get("/api/crawl-jobs", async (req, res) => {
    try {
      const jobs = await storage.getAllCrawlJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch crawl jobs" });
    }
  });

  // Get specific crawl job
  app.get("/api/crawl-jobs/:id", async (req, res) => {
    try {
      const job = await storage.getCrawlJob(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch crawl job" });
    }
  });

  // Create new crawl job
  app.post("/api/crawl-jobs", async (req, res) => {
    try {
      const validatedData = crawlConfigSchema.parse(req.body);
      const job = await storage.createCrawlJob(validatedData);
      res.json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create crawl job" });
    }
  });

  // Start crawl
  app.post("/api/crawl-jobs/:id/start", async (req, res) => {
    try {
      await crawlerService.startCrawl(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Failed to start crawl" });
    }
  });

  // Stop crawl
  app.post("/api/crawl-jobs/:id/stop", async (req, res) => {
    try {
      await crawlerService.stopCrawl(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Failed to stop crawl" });
    }
  });

  // Get crawl results
  app.get("/api/crawl-jobs/:id/results", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = (page - 1) * limit;

      const allResults = await storage.getCrawlResultsByJobId(req.params.id);
      const paginatedResults = allResults.slice(offset, offset + limit);
      
      res.json({
        results: paginatedResults,
        total: allResults.length,
        page,
        limit,
        totalPages: Math.ceil(allResults.length / limit)
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch crawl results" });
    }
  });

  // Export results as CSV
  app.get("/api/crawl-jobs/:id/export", async (req, res) => {
    try {
      const job = await storage.getCrawlJob(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      const csvFile = await crawlerService.generateCSV(req.params.id);
      const filename = `${job.outputFilename}.csv`;
      
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'text/csv');
      
      const fileStream = await fs.readFile(csvFile);
      res.send(fileStream);
      
      // Clean up temp file
      fs.unlink(csvFile).catch(console.error);
    } catch (error) {
      res.status(500).json({ error: "Failed to export results" });
    }
  });

  // Delete crawl job
  app.delete("/api/crawl-jobs/:id", async (req, res) => {
    try {
      await storage.deleteCrawlResultsByJobId(req.params.id);
      const deleted = await storage.deleteCrawlJob(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Job not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete crawl job" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
