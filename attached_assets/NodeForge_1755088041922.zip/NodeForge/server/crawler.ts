import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { storage } from './storage.js';
import type { CrawlJob, CrawlResult } from '@shared/schema';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export class CrawlerService {
  private activeJobs = new Map<string, any>();

  async startCrawl(jobId: string): Promise<void> {
    const job = await storage.getCrawlJob(jobId);
    if (!job) {
      throw new Error('Job not found');
    }

    if (this.activeJobs.has(jobId)) {
      throw new Error('Job is already running');
    }

    await storage.updateCrawlJob(jobId, { status: 'running' });

    try {
      await this.runCrawler(job);
    } catch (error) {
      await storage.updateCrawlJob(jobId, { 
        status: 'failed', 
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        completedAt: new Date()
      });
    }
  }

  async stopCrawl(jobId: string): Promise<void> {
    const process = this.activeJobs.get(jobId);
    if (process) {
      process.kill();
      this.activeJobs.delete(jobId);
      await storage.updateCrawlJob(jobId, { 
        status: 'failed', 
        errorMessage: 'Stopped by user',
        completedAt: new Date()
      });
    }
  }

  private async runCrawler(job: CrawlJob): Promise<void> {
    const tempFile = path.join(__dirname, '..', 'temp', `${job.id}.csv`);
    
    // Ensure temp directory exists
    await fs.mkdir(path.dirname(tempFile), { recursive: true });

    const crawlerScript = path.join(__dirname, '..', 'attached_assets', 'site_image_crawler_fixed.js');
    
    const args = [crawlerScript, job.targetUrl, tempFile];
    
    const crawlerProcess = spawn('node', args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env }
    });

    this.activeJobs.set(job.id, crawlerProcess);

    let output = '';
    
    crawlerProcess.stdout?.on('data', async (data) => {
      const text = data.toString();
      output += text;
      
      // Parse progress from output
      const crawledMatch = text.match(/Crawled: (.+?) \(found (\d+) images\)/);
      if (crawledMatch) {
        const currentUrl = crawledMatch[1];
        const currentImages = parseInt(crawledMatch[2]);
        
        const currentJob = await storage.getCrawlJob(job.id);
        if (currentJob) {
          await storage.updateCrawlJob(job.id, {
            currentUrl,
            pagesVisited: (currentJob.pagesVisited || 0) + 1,
            imagesFound: (currentJob.imagesFound || 0) + currentImages
          });
        }
      }
    });

    crawlerProcess.stderr?.on('data', (data) => {
      console.error(`Crawler error: ${data}`);
    });

    crawlerProcess.stdout?.on('data', (data) => {
      console.log(`Crawler stdout: ${data}`);
    });

    crawlerProcess.on('close', async (code) => {
      this.activeJobs.delete(job.id);
      
      if (code === 0) {
        // Parse CSV and save results
        try {
          await this.parseCrawlResults(job.id, tempFile);
          await storage.updateCrawlJob(job.id, { 
            status: 'completed',
            completedAt: new Date()
          });
        } catch (error) {
          await storage.updateCrawlJob(job.id, { 
            status: 'failed', 
            errorMessage: 'Failed to parse results',
            completedAt: new Date()
          });
        }
      } else {
        await storage.updateCrawlJob(job.id, { 
          status: 'failed', 
          errorMessage: `Crawler exited with code ${code}`,
          completedAt: new Date()
        });
      }
    });
  }

  private async parseCrawlResults(jobId: string, csvFile: string): Promise<void> {
    try {
      const csvContent = await fs.readFile(csvFile, 'utf-8');
      const lines = csvContent.split('\n').slice(1); // Skip header
      
      for (const line of lines) {
        if (line.trim()) {
          const [pageUrl, imageUrl, altText, imgTagHtml] = this.parseCSVLine(line);
          
          if (pageUrl && imageUrl) {
            await storage.createCrawlResult({
              jobId,
              pageUrl,
              imageUrl,
              altText: altText || '',
              imgTagHtml: imgTagHtml || ''
            });
          }
        }
      }
    } catch (error) {
      console.error('Error parsing CSV:', error);
      throw error;
    }
  }

  private parseCSVLine(line: string): string[] {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current);
    return result;
  }

  async getJobProgress(jobId: string): Promise<CrawlJob | null> {
    const job = await storage.getCrawlJob(jobId);
    return job || null;
  }

  async generateCSV(jobId: string): Promise<string> {
    const job = await storage.getCrawlJob(jobId);
    const results = await storage.getCrawlResultsByJobId(jobId);
    
    if (!job) throw new Error('Job not found');
    
    const tempFile = path.join(__dirname, '..', 'temp', `export_${jobId}.csv`);
    
    const header = 'page_url,image_url,alt_text,img_tag_html\n';
    const rows = results.map(r => 
      `"${r.pageUrl}","${r.imageUrl}","${r.altText || ''}","${r.imgTagHtml || ''}"`
    ).join('\n');
    
    await fs.writeFile(tempFile, header + rows);
    return tempFile;
  }
}

export const crawlerService = new CrawlerService();
