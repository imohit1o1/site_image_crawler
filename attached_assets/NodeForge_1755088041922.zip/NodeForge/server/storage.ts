import { type CrawlJob, type InsertCrawlJob, type CrawlResult, type InsertCrawlResult } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Crawl Jobs
  createCrawlJob(job: InsertCrawlJob): Promise<CrawlJob>;
  getCrawlJob(id: string): Promise<CrawlJob | undefined>;
  getAllCrawlJobs(): Promise<CrawlJob[]>;
  updateCrawlJob(id: string, updates: Partial<CrawlJob>): Promise<CrawlJob | undefined>;
  deleteCrawlJob(id: string): Promise<boolean>;
  
  // Crawl Results
  createCrawlResult(result: InsertCrawlResult): Promise<CrawlResult>;
  getCrawlResultsByJobId(jobId: string): Promise<CrawlResult[]>;
  deleteCrawlResultsByJobId(jobId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private crawlJobs: Map<string, CrawlJob>;
  private crawlResults: Map<string, CrawlResult>;

  constructor() {
    this.crawlJobs = new Map();
    this.crawlResults = new Map();
  }

  async createCrawlJob(insertJob: InsertCrawlJob): Promise<CrawlJob> {
    const id = randomUUID();
    const job: CrawlJob = { 
      ...insertJob, 
      id,
      status: "pending",
      pagesVisited: 0,
      imagesFound: 0,
      currentUrl: null,
      errorMessage: null,
      createdAt: new Date(),
      completedAt: null,
      maxPages: insertJob.maxPages ?? 500,
      pageTimeout: insertJob.pageTimeout ?? 60,
      includeBackgroundImages: insertJob.includeBackgroundImages ?? true,
    };
    this.crawlJobs.set(id, job);
    return job;
  }

  async getCrawlJob(id: string): Promise<CrawlJob | undefined> {
    return this.crawlJobs.get(id);
  }

  async getAllCrawlJobs(): Promise<CrawlJob[]> {
    return Array.from(this.crawlJobs.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async updateCrawlJob(id: string, updates: Partial<CrawlJob>): Promise<CrawlJob | undefined> {
    const job = this.crawlJobs.get(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...updates };
    this.crawlJobs.set(id, updatedJob);
    return updatedJob;
  }

  async deleteCrawlJob(id: string): Promise<boolean> {
    return this.crawlJobs.delete(id);
  }

  async createCrawlResult(insertResult: InsertCrawlResult): Promise<CrawlResult> {
    const id = randomUUID();
    const result: CrawlResult = {
      ...insertResult,
      id,
      createdAt: new Date(),
      altText: insertResult.altText ?? null,
      imgTagHtml: insertResult.imgTagHtml ?? null,
    };
    this.crawlResults.set(id, result);
    return result;
  }

  async getCrawlResultsByJobId(jobId: string): Promise<CrawlResult[]> {
    return Array.from(this.crawlResults.values())
      .filter(result => result.jobId === jobId)
      .sort((a, b) => new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime());
  }

  async deleteCrawlResultsByJobId(jobId: string): Promise<boolean> {
    let deleted = false;
    const entries = Array.from(this.crawlResults.entries());
    for (const [id, result] of entries) {
      if (result.jobId === jobId) {
        this.crawlResults.delete(id);
        deleted = true;
      }
    }
    return deleted;
  }
}

export const storage = new MemStorage();
