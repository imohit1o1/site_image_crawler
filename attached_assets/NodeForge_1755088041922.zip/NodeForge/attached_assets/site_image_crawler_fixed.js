#!/usr/bin/env node

import puppeteer from 'puppeteer';
import { createObjectCsvWriter } from 'csv-writer';

const [,, siteUrl, outCsv] = process.argv;

if (!siteUrl || !outCsv) {
  console.error('Usage: node site_image_crawler.js <site_url> <output_csv>');
  process.exit(1);
}

async function extractImagesFromPage(page) {
  return await page.evaluate(() => {
    const images = [];
    
    // Extract images from <img> tags
    document.querySelectorAll('img').forEach((img, idx) => {
      const src = img.src || img.dataset.src || img.dataset.lazySrc;
      if (src && !src.startsWith('data:')) {
        images.push({
          image_url: src,
          alt_text: img.alt || '',
          html: img.outerHTML
        });
      }
    });
    
    // Extract images from <picture> elements
    document.querySelectorAll('picture img').forEach((img, idx) => {
      const src = img.src || img.dataset.src;
      if (src && !src.startsWith('data:')) {
        images.push({
          image_url: src,
          alt_text: img.alt || '',
          html: img.parentElement.outerHTML
        });
      }
    });
    
    // Extract background images from CSS
    const allElements = document.querySelectorAll('*');
    allElements.forEach((el, idx) => {
      const style = window.getComputedStyle(el);
      const bgImage = style.backgroundImage;
      if (bgImage && bgImage !== 'none' && bgImage.includes('url(')) {
        const match = bgImage.match(/url\(['"]?([^'")]+)['"]?\)/);
        if (match && match[1] && !match[1].startsWith('data:')) {
          images.push({
            image_url: match[1],
            alt_text: el.getAttribute('alt') || el.getAttribute('title') || '',
            html: el.outerHTML.slice(0, 200)
          });
        }
      }
    });
    
    return images;
  });
}

function normalizeUrl(baseUrl, relativeUrl) {
  try {
    if (relativeUrl.startsWith('http')) return relativeUrl;
    return new URL(relativeUrl, baseUrl).toString();
  } catch (e) {
    return null;
  }
}

(async () => {
  console.log(`Starting crawler for: ${siteUrl}`);
  
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: '/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium-browser',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--no-first-run',
      '--disable-default-apps',
      '--disable-features=VizDisplayCompositor'
    ]
  });

  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
  await page.setViewport({ width: 1280, height: 720 });

  const results = [];
  const visited = new Set();
  const toVisit = [siteUrl];
  const origin = new URL(siteUrl).origin;

  // Add timeout and error handling
  page.setDefaultNavigationTimeout(30000);
  page.setDefaultTimeout(30000);

  while (toVisit.length > 0 && visited.size < 50) { // Limit to 50 pages for performance
    const url = toVisit.shift();
    if (!url) continue;
    if (visited.has(url)) continue;
    visited.add(url);
    
    try {
      await page.goto(url, {waitUntil: 'networkidle2', timeout: 30000});
      // Wait for JavaScript-heavy sites using proper method
      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch(err) {
      console.warn('Failed to load', url, err.message);
      continue;
    }

    // Extract links for BFS - enhanced for SPAs
    const links = await page.evaluate(() => {
      const allLinks = new Set();
      
      // Standard <a> tags
      document.querySelectorAll('a[href]').forEach(a => {
        try {
          const href = a.getAttribute('href');
          if (href) {
            allLinks.add(new URL(href, window.location.href).href);
          }
        } catch(e) {}
      });
      
      // Look for navigation elements
      document.querySelectorAll('nav a, .nav a, .menu a, .navigation a').forEach(a => {
        if (a.href) allLinks.add(a.href);
      });
      
      // Look for buttons that might be navigation (React Router)
      document.querySelectorAll('button[data-href], [role="link"]').forEach(el => {
        const href = el.getAttribute('data-href') || el.getAttribute('href');
        if (href) {
          try {
            allLinks.add(new URL(href, window.location.href).href);
          } catch(e) {}
        }
      });
      
      return Array.from(allLinks);
    });

    // Add discovered links to queue
    for (const link of links) {
      try {
        const linkUrl = new URL(link);
        if (linkUrl.origin === origin) {
          const cleanUrl = linkUrl.toString().split('#')[0];
          if (!visited.has(cleanUrl) && !toVisit.includes(cleanUrl)) {
            toVisit.push(cleanUrl);
          }
        }
      } catch(e) {}
    }

    // Extract images
    const images = await extractImagesFromPage(page);
    for (const img of images) {
      const fullUrl = normalizeUrl(url, img.image_url);
      if (!fullUrl) continue;
      
      results.push({
        page_url: url,
        image_url: fullUrl,
        alt_text: img.alt_text || '',
        img_tag_html: img.html.replace(/\n|\r/g, ' ').slice(0, 400)
      });
    }

    console.log(`Crawled: ${url} (found ${images.length} images, discovered ${links.length} links)`);
  }

  await browser.close();

  // Deduplicate results
  const unique = [];
  const seen = new Set();
  for (const result of results) {
    const key = result.page_url + '||' + result.image_url;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(result);
    }
  }

  console.log(`Total unique images found: ${unique.length}`);

  // Write to CSV
  const csvWriter = createObjectCsvWriter({
    path: outCsv,
    header: [
      {id: 'page_url', title: 'page_url'},
      {id: 'image_url', title: 'image_url'},
      {id: 'alt_text', title: 'alt_text'},
      {id: 'img_tag_html', title: 'img_tag_html'}
    ]
  });

  await csvWriter.writeRecords(unique);
  console.log(`Results saved to: ${outCsv}`);
})();