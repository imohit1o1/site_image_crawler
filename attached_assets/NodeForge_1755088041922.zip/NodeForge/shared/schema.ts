import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const crawlJobs = pgTable("crawl_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  targetUrl: text("target_url").notNull(),
  outputFilename: text("output_filename").notNull(),
  maxPages: integer("max_pages").default(500),
  pageTimeout: integer("page_timeout").default(60),
  includeBackgroundImages: boolean("include_background_images").default(true),
  status: text("status").notNull().default("pending"), // pending, running, completed, failed, paused
  pagesVisited: integer("pages_visited").default(0),
  imagesFound: integer("images_found").default(0),
  currentUrl: text("current_url"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").default(sql`now()`),
  completedAt: timestamp("completed_at"),
});

export const crawlResults = pgTable("crawl_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  jobId: varchar("job_id").notNull().references(() => crawlJobs.id, { onDelete: 'cascade' }),
  pageUrl: text("page_url").notNull(),
  imageUrl: text("image_url").notNull(),
  altText: text("alt_text"),
  imgTagHtml: text("img_tag_html"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertCrawlJobSchema = createInsertSchema(crawlJobs).omit({
  id: true,
  status: true,
  pagesVisited: true,
  imagesFound: true,
  currentUrl: true,
  errorMessage: true,
  createdAt: true,
  completedAt: true,
});

export const insertCrawlResultSchema = createInsertSchema(crawlResults).omit({
  id: true,
  createdAt: true,
});

export const crawlConfigSchema = z.object({
  targetUrl: z.string().url("Please enter a valid URL"),
  outputFilename: z.string().min(1, "Output filename is required"),
  maxPages: z.number().min(1).max(10000),
  pageTimeout: z.number().min(10).max(300),
  includeBackgroundImages: z.boolean().default(true),
});

export type CrawlJob = typeof crawlJobs.$inferSelect;
export type InsertCrawlJob = z.infer<typeof insertCrawlJobSchema>;
export type CrawlResult = typeof crawlResults.$inferSelect;
export type InsertCrawlResult = z.infer<typeof insertCrawlResultSchema>;
export type CrawlConfig = z.infer<typeof crawlConfigSchema>;
