import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { CrawlJob } from "@shared/schema";

interface ProgressTrackerProps {
  job: CrawlJob;
  onRefetch: () => void;
}

export default function ProgressTracker({ job, onRefetch }: ProgressTrackerProps) {
  const { toast } = useToast();

  // Poll for updates when job is running
  const { data: currentJob } = useQuery<CrawlJob>({
    queryKey: ["/api/crawl-jobs", job.id],
    refetchInterval: job.status === "running" ? 2000 : false,
    enabled: !!job.id,
  });

  const displayJob = currentJob || job;

  useEffect(() => {
    if (currentJob?.status !== job.status) {
      onRefetch();
    }
  }, [currentJob?.status, job.status, onRefetch]);

  const handleStop = async () => {
    try {
      await apiRequest("POST", `/api/crawl-jobs/${job.id}/stop`);
      toast({
        title: "Crawl Stopped",
        description: "The crawling process has been stopped",
      });
      onRefetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to stop crawling",
        variant: "destructive",
      });
    }
  };

  const handlePause = async () => {
    // Note: Pause functionality would need to be implemented in the crawler service
    toast({
      title: "Feature Not Available",
      description: "Pause functionality is not yet implemented",
      variant: "destructive",
    });
  };

  const progressPercentage = displayJob.maxPages && displayJob.maxPages > 0 
    ? Math.min((displayJob.pagesVisited || 0) / displayJob.maxPages * 100, 100)
    : 0;

  if (displayJob.status === "pending") {
    return null;
  }

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-chart-line mr-2 text-primary-500"></i>
          Crawling Progress
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-500">
                {displayJob.pagesVisited || 0}
              </div>
              <div className="text-sm text-gray-600">Pages Visited</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500">
                {displayJob.imagesFound || 0}
              </div>
              <div className="text-sm text-gray-600">Images Found</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-500">
                {displayJob.status === "running" ? "~2.3s" : "--"}
              </div>
              <div className="text-sm text-gray-600">Avg. Page Load</div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Progress</span>
              <span className="font-medium">
                {displayJob.pagesVisited || 0} / {displayJob.maxPages || "∞"} pages
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-primary-500 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
          </div>

          {/* Current Status */}
          {displayJob.status === "running" && displayJob.currentUrl && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <div className="animate-spin">
                  <i className="fas fa-spinner text-blue-500"></i>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium text-blue-900">Currently crawling:</div>
                  <div className="text-sm text-blue-700 break-all">
                    {displayJob.currentUrl}
                  </div>
                </div>
              </div>
            </div>
          )}

          {displayJob.status === "completed" && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <div className="text-green-500">
                  <i className="fas fa-check-circle"></i>
                </div>
                <div>
                  <div className="text-sm font-medium text-green-900">
                    Crawling completed successfully!
                  </div>
                  <div className="text-sm text-green-700">
                    Found {displayJob.imagesFound} images across {displayJob.pagesVisited} pages
                  </div>
                </div>
              </div>
            </div>
          )}

          {displayJob.status === "failed" && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center space-x-3">
                <div className="text-red-500">
                  <i className="fas fa-exclamation-circle"></i>
                </div>
                <div>
                  <div className="text-sm font-medium text-red-900">Crawling failed</div>
                  <div className="text-sm text-red-700">
                    {displayJob.errorMessage || "Unknown error occurred"}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Control Buttons */}
          {displayJob.status === "running" && (
            <div className="flex space-x-3">
              <Button
                onClick={handlePause}
                variant="outline"
                className="bg-orange-500 hover:bg-orange-600 text-white border-orange-500"
              >
                <i className="fas fa-pause mr-2"></i>
                Pause
              </Button>
              <Button
                onClick={handleStop}
                variant="outline"
                className="bg-red-500 hover:bg-red-600 text-white border-red-500"
              >
                <i className="fas fa-stop mr-2"></i>
                Stop
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
