import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ImagePreviewModalProps {
  imageUrl: string;
  pageUrl: string;
  altText: string;
  onClose: () => void;
}

export default function ImagePreviewModal({
  imageUrl,
  pageUrl,
  altText,
  onClose,
}: ImagePreviewModalProps) {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-screen overflow-auto">
        <DialogHeader>
          <DialogTitle>Image Preview</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="relative bg-gray-50 rounded-lg overflow-hidden">
            <img
              src={imageUrl}
              alt={altText}
              className="w-full h-auto rounded-lg shadow-lg max-h-[70vh] object-contain mx-auto"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjYwMCIgdmlld0JveD0iMCAwIDgwMCA2MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI4MDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik0zNzAgMjcwSDQzMFYzMzBIMzcwVjI3MFoiIGZpbGw9IiM5Q0EzQUYiLz4KPHA7dGggZD0iTTMwMCAyNDBINTAwVjM2MEgzMDBWMjQwWiIgc3Ryb2tlPSIjOUNBM0FGIiBzdHJva2Utd2lkdGg9IjQiLz4KPHA7dGggZD0iTTM1MCAzODBINDUwIiBzdHJva2U9IiM5Q0EzQUYiIHN0cm9rZS13aWR0aD0iMiIvPgo8L3N2Zz4=";
              }}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="font-medium text-gray-700">Image URL:</div>
              <div className="text-gray-900 break-all">{imageUrl}</div>
            </div>
            <div>
              <div className="font-medium text-gray-700">Page URL:</div>
              <div className="text-blue-600">
                <a href={pageUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">
                  {pageUrl}
                </a>
              </div>
            </div>
            <div>
              <div className="font-medium text-gray-700">Alt Text:</div>
              <div className="text-gray-900">{altText || "No alt text"}</div>
            </div>
            <div>
              <div className="font-medium text-gray-700">Actions:</div>
              <div className="space-x-4">
                <button
                  onClick={() => window.open(imageUrl, "_blank")}
                  className="text-blue-600 hover:text-blue-800 underline text-sm"
                >
                  <i className="fas fa-external-link-alt mr-1"></i>
                  Open in new tab
                </button>
                <button
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(imageUrl);
                    } catch (err) {
                      console.error('Failed to copy:', err);
                    }
                  }}
                  className="text-green-600 hover:text-green-800 underline text-sm"
                >
                  <i className="fas fa-copy mr-1"></i>
                  Copy URL
                </button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
