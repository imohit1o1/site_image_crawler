import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { crawlConfigSchema, type CrawlConfig } from "@shared/schema";

interface CrawlerConfigProps {
  onCrawlStart: (jobId: string) => void;
}

export default function CrawlerConfig({ onCrawlStart }: CrawlerConfigProps) {
  const { toast } = useToast();
  const [isStarting, setIsStarting] = useState(false);

  const form = useForm<CrawlConfig>({
    resolver: zodResolver(crawlConfigSchema),
    defaultValues: {
      targetUrl: "",
      outputFilename: "images_export",
      maxPages: 500,
      pageTimeout: 60,
      includeBackgroundImages: true,
    },
  });

  const createJobMutation = useMutation({
    mutationFn: async (data: CrawlConfig) => {
      const response = await apiRequest("POST", "/api/crawl-jobs", data);
      return response.json();
    },
    onSuccess: async (job) => {
      try {
        setIsStarting(true);
        await apiRequest("POST", `/api/crawl-jobs/${job.id}/start`);
        onCrawlStart(job.id);
        toast({
          title: "Crawl Started",
          description: `Started crawling ${form.getValues("targetUrl")}`,
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to start crawling",
          variant: "destructive",
        });
      } finally {
        setIsStarting(false);
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create crawl job",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CrawlConfig) => {
    createJobMutation.mutate(data);
  };

  const handleReset = () => {
    form.reset();
  };

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-cog mr-2 text-primary-500"></i>
          Crawler Configuration
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* URL Input */}
            <div className="space-y-2">
              <Label htmlFor="target-url">
                Target URL <span className="text-red-500">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="target-url"
                  type="url"
                  placeholder="https://example.com"
                  className="pl-10"
                  {...form.register("targetUrl")}
                />
                <i className="fas fa-globe absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
              <p className="text-xs text-gray-500">Enter the starting URL to begin crawling</p>
              {form.formState.errors.targetUrl && (
                <p className="text-xs text-red-500">{form.formState.errors.targetUrl.message}</p>
              )}
            </div>

            {/* Output Filename */}
            <div className="space-y-2">
              <Label htmlFor="output-file">Output Filename</Label>
              <div className="relative">
                <Input
                  id="output-file"
                  placeholder="images_export"
                  className="pl-10"
                  {...form.register("outputFilename")}
                />
                <i className="fas fa-file-csv absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
              <p className="text-xs text-gray-500">.csv extension will be added automatically</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Max Pages */}
            <div className="space-y-2">
              <Label htmlFor="max-pages">Max Pages</Label>
              <Select
                value={form.watch("maxPages")?.toString()}
                onValueChange={(value) => form.setValue("maxPages", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select max pages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="100">100 pages</SelectItem>
                  <SelectItem value="500">500 pages</SelectItem>
                  <SelectItem value="1000">1000 pages</SelectItem>
                  <SelectItem value="10000">Unlimited</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Timeout */}
            <div className="space-y-2">
              <Label htmlFor="timeout">Page Timeout</Label>
              <Select
                value={form.watch("pageTimeout")?.toString()}
                onValueChange={(value) => form.setValue("pageTimeout", parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select timeout" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 seconds</SelectItem>
                  <SelectItem value="60">60 seconds</SelectItem>
                  <SelectItem value="120">120 seconds</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Include Background Images */}
            <div className="space-y-2">
              <Label>Options</Label>
              <div className="flex items-center space-x-4 pt-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="include-bg"
                    checked={form.watch("includeBackgroundImages")}
                    onCheckedChange={(checked) => 
                      form.setValue("includeBackgroundImages", !!checked)
                    }
                  />
                  <Label htmlFor="include-bg" className="text-sm text-gray-700">
                    Include CSS backgrounds
                  </Label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={handleReset}
              disabled={createJobMutation.isPending || isStarting}
            >
              Reset
            </Button>
            <Button
              type="submit"
              disabled={createJobMutation.isPending || isStarting}
              className="bg-primary-500 hover:bg-primary-600"
            >
              {createJobMutation.isPending || isStarting ? (
                <div className="flex items-center space-x-2">
                  <i className="fas fa-spinner animate-spin"></i>
                  <span>Starting...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <i className="fas fa-play"></i>
                  <span>Start Crawling</span>
                </div>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
