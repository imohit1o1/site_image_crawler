import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { CrawlJob } from "@shared/schema";

interface RecentCrawlsProps {
  jobs: CrawlJob[];
  onViewJob: (jobId: string) => void;
  onRefetch: () => void;
}

export default function RecentCrawls({ jobs, onViewJob, onRefetch }: RecentCrawlsProps) {
  const { toast } = useToast();

  const handleDownload = async (jobId: string) => {
    try {
      const response = await fetch(`/api/crawl-jobs/${jobId}/export`);
      if (!response.ok) throw new Error("Failed to export");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `crawl_results_${jobId}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Export Successful",
        description: "CSV file has been downloaded",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export CSV file",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500";
      case "running":
        return "bg-blue-500";
      case "failed":
        return "bg-red-500";
      case "paused":
        return "bg-orange-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusText = (job: CrawlJob) => {
    switch (job.status) {
      case "completed":
        return `${job.imagesFound} images • Completed ${getTimeAgo(job.completedAt)}`;
      case "running":
        return "Currently running";
      case "failed":
        return `Failed • ${job.errorMessage || "Unknown error"}`;
      case "paused":
        return "Paused";
      default:
        return "Pending";
    }
  };

  const getTimeAgo = (date: Date | null) => {
    if (!date) return "recently";
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    return "recently";
  };

  const extractDomain = (url: string) => {
    try {
      return new URL(url).hostname;
    } catch {
      return url;
    }
  };

  if (!jobs.length) {
    return (
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-history mr-2 text-primary-500"></i>
            Recent Crawls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <i className="fas fa-clock text-4xl text-gray-300 mb-4"></i>
            <p className="text-gray-500">No crawls yet</p>
            <p className="text-sm text-gray-400">Your recent crawl history will appear here</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-history mr-2 text-primary-500"></i>
          Recent Crawls
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {jobs.slice(0, 10).map((job) => (
            <div
              key={job.id}
              className={`flex items-center justify-between p-4 rounded-lg ${
                job.status === "failed" ? "bg-red-50" : "bg-gray-50"
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className={`w-2 h-2 ${getStatusColor(job.status)} rounded-full`}></div>
                <div>
                  <div className="font-medium text-gray-900">
                    {extractDomain(job.targetUrl)}
                  </div>
                  <div className={`text-sm ${
                    job.status === "failed" ? "text-red-500" : "text-gray-500"
                  }`}>
                    {getStatusText(job)}
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                {job.status === "completed" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDownload(job.id)}
                    className="text-blue-600 hover:text-blue-800 border-blue-300"
                  >
                    <i className="fas fa-download"></i>
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onViewJob(job.id)}
                  className="text-gray-600 hover:text-gray-800 border-gray-300"
                >
                  <i className="fas fa-eye"></i>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
