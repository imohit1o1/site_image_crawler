import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import type { CrawlResult } from "@shared/schema";

interface ResultsTableProps {
  jobId: string;
  onPreviewImage: (imageUrl: string, pageUrl: string, altText: string) => void;
}

interface ResultsResponse {
  results: CrawlResult[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export default function ResultsTable({ jobId, onPreviewImage }: ResultsTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();

  const { data: resultsData, isLoading } = useQuery<ResultsResponse>({
    queryKey: ["/api/crawl-jobs", jobId, "results", currentPage],
    queryFn: async () => {
      const response = await fetch(`/api/crawl-jobs/${jobId}/results?page=${currentPage}&limit=20`);
      if (!response.ok) throw new Error("Failed to fetch results");
      return response.json();
    },
    enabled: !!jobId,
  });

  const handleExportCSV = async () => {
    try {
      const response = await fetch(`/api/crawl-jobs/${jobId}/export`);
      if (!response.ok) throw new Error("Failed to export");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `crawl_results_${jobId}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Export Successful",
        description: "CSV file has been downloaded",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export CSV file",
        variant: "destructive",
      });
    }
  };

  const handleCopyUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast({
        title: "Copied",
        description: "URL copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy URL",
        variant: "destructive",
      });
    }
  };

  if (!resultsData && !isLoading) {
    return null;
  }

  return (
    <Card className="mb-8">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center">
            <i className="fas fa-table mr-2 text-primary-500"></i>
            Crawling Results
          </CardTitle>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-600">
              {resultsData?.total || 0} images found
            </div>
            <Button
              onClick={handleExportCSV}
              className="bg-green-500 hover:bg-green-600"
              disabled={!resultsData?.results?.length}
            >
              <i className="fas fa-download mr-2"></i>
              Export CSV
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="p-6 text-center">
            <i className="fas fa-spinner animate-spin text-2xl text-gray-400 mb-4"></i>
            <p className="text-gray-500">Loading results...</p>
          </div>
        ) : !resultsData?.results?.length ? (
          <div className="p-6 text-center">
            <i className="fas fa-image text-4xl text-gray-300 mb-4"></i>
            <p className="text-gray-500">No images found yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Image Preview
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Image URL
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Page URL
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Alt Text
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {resultsData.results.map((result) => (
                  <tr key={result.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="relative group">
                        <img
                          src={result.imageUrl}
                          alt={result.altText || "Image preview"}
                          className="w-16 h-16 object-cover rounded-lg cursor-pointer transition-transform hover:scale-105 shadow-sm"
                          onClick={() => onPreviewImage(result.imageUrl, result.pageUrl, result.altText || "")}
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjQiIGhlaWdodD0iNjQiIHZpZXdCb3g9IjAgMCA2NCA2NCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjY0IiBoZWlnaHQ9IjY0IiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik0yOCAyOEgzNlYzNkgyOFYyOFoiIGZpbGw9IiM5Q0EzQUYiLz4KPHA7dGggZD0iTTI0IDI0SDQwVjQwSDI0VjI0WiIgc3Ryb2tlPSIjOUNBM0FGIiBzdHJva2Utd2lkdGg9IjIiLz4KPC9zdmc+";
                          }}
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-lg transition-opacity flex items-center justify-center">
                          <i className="fas fa-search-plus text-white opacity-0 group-hover:opacity-100 transition-opacity"></i>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900 break-all max-w-xs truncate">
                        {result.imageUrl}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-blue-600 hover:text-blue-800 cursor-pointer max-w-xs truncate">
                        <a href={result.pageUrl} target="_blank" rel="noopener noreferrer">
                          {result.pageUrl}
                        </a>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-900">
                        {result.altText || "--"}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => onPreviewImage(result.imageUrl, result.pageUrl, result.altText || "")}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <i className="fas fa-eye"></i>
                        </button>
                        <button
                          onClick={() => handleCopyUrl(result.imageUrl)}
                          className="text-gray-600 hover:text-gray-800"
                        >
                          <i className="fas fa-copy"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {resultsData && resultsData.totalPages > 1 && (
          <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-700">
                Showing{" "}
                <span className="font-medium">
                  {(resultsData.page - 1) * resultsData.limit + 1}
                </span>{" "}
                to{" "}
                <span className="font-medium">
                  {Math.min(resultsData.page * resultsData.limit, resultsData.total)}
                </span>{" "}
                of <span className="font-medium">{resultsData.total}</span> results
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  <i className="fas fa-chevron-left"></i>
                </Button>
                {Array.from({ length: Math.min(5, resultsData.totalPages) }, (_, i) => {
                  const pageNum = i + 1;
                  return (
                    <Button
                      key={pageNum}
                      variant={currentPage === pageNum ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(pageNum)}
                      className={currentPage === pageNum ? "bg-primary-500 text-white" : ""}
                    >
                      {pageNum}
                    </Button>
                  );
                })}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.min(resultsData.totalPages, p + 1))}
                  disabled={currentPage === resultsData.totalPages}
                >
                  <i className="fas fa-chevron-right"></i>
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
