import { useState } from "react";
import CrawlerConfig from "@/components/crawler-config";
import ProgressTracker from "@/components/progress-tracker";
import ResultsTable from "@/components/results-table";
import RecentCrawls from "@/components/recent-crawls";
import ImagePreviewModal from "@/components/image-preview-modal";
import { useQuery } from "@tanstack/react-query";
import type { CrawlJob } from "@shared/schema";

export default function Home() {
  const [activeCrawlId, setActiveCrawlId] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<{
    imageUrl: string;
    pageUrl: string;
    altText: string;
  } | null>(null);

  const { data: crawlJobs = [], refetch: refetchJobs } = useQuery<CrawlJob[]>({
    queryKey: ["/api/crawl-jobs"],
  });

  const handleCrawlStart = (jobId: string) => {
    setActiveCrawlId(jobId);
    refetchJobs();
  };

  const handlePreviewImage = (imageUrl: string, pageUrl: string, altText: string) => {
    setPreviewImage({ imageUrl, pageUrl, altText });
  };

  const handleClosePreview = () => {
    setPreviewImage(null);
  };

  const getJobStatus = (job: CrawlJob) => {
    switch (job.status) {
      case "running":
        return { color: "bg-blue-500", text: "Running" };
      case "completed":
        return { color: "bg-green-500", text: "Ready" };
      case "failed":
        return { color: "bg-red-500", text: "Error" };
      case "paused":
        return { color: "bg-orange-500", text: "Paused" };
      default:
        return { color: "bg-gray-400", text: "Ready" };
    }
  };

  const activeJob = activeCrawlId ? crawlJobs.find(job => job.id === activeCrawlId) : null;
  const latestJob = crawlJobs.length > 0 ? crawlJobs[0] : null;
  const displayJob = activeJob || latestJob;
  const jobStatus = displayJob ? getJobStatus(displayJob) : { color: "bg-gray-400", text: "Ready" };

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <i className="fas fa-spider text-primary-500 text-2xl"></i>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Site Image Crawler</h1>
                <p className="text-sm text-gray-600">Extract images from any website with ease</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-100">
                <div className={`w-2 h-2 ${jobStatus.color} rounded-full`}></div>
                <span className="text-sm text-gray-700">{jobStatus.text}</span>
              </div>
              <button className="text-gray-500 hover:text-gray-700">
                <i className="fas fa-question-circle text-lg"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <CrawlerConfig onCrawlStart={handleCrawlStart} />
        
        {displayJob && (
          <>
            <ProgressTracker 
              job={displayJob} 
              onRefetch={refetchJobs}
            />
            <ResultsTable 
              jobId={displayJob.id} 
              onPreviewImage={handlePreviewImage}
            />
          </>
        )}
        
        <RecentCrawls 
          jobs={crawlJobs} 
          onViewJob={setActiveCrawlId}
          onRefetch={refetchJobs}
        />
        
        {previewImage && (
          <ImagePreviewModal
            imageUrl={previewImage.imageUrl}
            pageUrl={previewImage.pageUrl}
            altText={previewImage.altText}
            onClose={handleClosePreview}
          />
        )}
      </div>
    </div>
  );
}
