# Overview

This is a web-based image crawler application built with a modern full-stack architecture. The application allows users to crawl websites to extract image URLs, alt text, and HTML content, then export the results to CSV format. It features a React frontend with a shadcn/ui component library and an Express.js backend with PostgreSQL database integration via Drizzle ORM.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **Forms**: React Hook Form with Zod validation for type-safe form handling

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **API Design**: RESTful API with standardized error handling and logging middleware
- **Crawling Engine**: Puppeteer-based web crawler with configurable options

## Data Storage Solutions
- **Primary Database**: PostgreSQL hosted on Neon (serverless PostgreSQL)
- **ORM**: Drizzle ORM with schema-first approach
- **Schema**: Two main tables - `crawl_jobs` for tracking crawl configurations and status, `crawl_results` for storing extracted image data
- **Storage Pattern**: In-memory storage fallback for development/testing scenarios

## Authentication and Authorization
- Currently implements a simple session-based approach
- Uses `connect-pg-simple` for PostgreSQL session storage
- No complex authentication system implemented - appears to be designed for single-user or trusted environment usage

## Core Features
- **Web Crawling**: Configurable website crawling with Puppeteer using system Chromium browser
- **Image Extraction**: Extracts images from `<img>` tags, `<picture>` elements, and CSS background images
- **SPA Support**: Enhanced link discovery for single-page applications (Next.js, React Router)
- **Job Management**: Create, start, stop, and monitor crawl jobs with real-time status updates
- **Data Export**: CSV export functionality for crawl results
- **Progress Tracking**: Real-time progress monitoring with polling-based updates

## Development Environment
- **Hot Reload**: Vite development server with HMR
- **Type Safety**: Full TypeScript implementation across frontend and backend
- **Code Organization**: Monorepo structure with shared schema definitions
- **Build Process**: Separate build processes for client (Vite) and server (esbuild)

# External Dependencies

## Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL client for Neon database
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **drizzle-kit**: CLI tool for database migrations and schema management

## Frontend Dependencies
- **@tanstack/react-query**: Server state management and data fetching
- **@radix-ui/***: Headless UI components for accessibility
- **react-hook-form**: Form state management and validation
- **@hookform/resolvers**: Form validation resolvers
- **wouter**: Lightweight client-side routing
- **date-fns**: Date utility library
- **tailwindcss**: Utility-first CSS framework

## Backend Dependencies
- **puppeteer**: Headless Chrome automation for web crawling
- **express**: Web application framework
- **connect-pg-simple**: PostgreSQL session store
- **csv-writer**: CSV file generation
- **zod**: Runtime type validation

## Development Dependencies
- **vite**: Frontend build tool and development server
- **typescript**: Type checking and compilation
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production builds

## Replit-Specific Integration
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Replit-specific development tooling